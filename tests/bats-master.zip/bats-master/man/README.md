Bats man pages are generated with [Ronn](http://rtomayko.github.io/ronn/).

After making changes to `bats.1.ronn` or `bats.7.ronn`, run `make` in
this directory to generate `bats.1` and `bats.7`. **Do not edit the
`bats.1` or `bats.7` files directly.**
